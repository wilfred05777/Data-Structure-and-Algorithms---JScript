const Stack = require('./stack');

class Node {}

function depthFirstTraversal() {}

module.exports = {
  Node,
  depthFirstTraversal,
};
