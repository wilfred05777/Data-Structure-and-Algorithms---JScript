const Stack = require('./stack');

