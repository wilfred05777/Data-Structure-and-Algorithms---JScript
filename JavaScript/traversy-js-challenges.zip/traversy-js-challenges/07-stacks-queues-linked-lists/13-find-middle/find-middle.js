function findMiddle() {}

module.exports = findMiddle;
