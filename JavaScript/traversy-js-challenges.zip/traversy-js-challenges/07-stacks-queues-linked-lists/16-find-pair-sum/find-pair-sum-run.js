const findPairSum = require('./find-pair-sum');

const nums = [2, 6, 12, 11, 6, 10];
const targetSum = 22;

const result = findPairSum(nums, targetSum);