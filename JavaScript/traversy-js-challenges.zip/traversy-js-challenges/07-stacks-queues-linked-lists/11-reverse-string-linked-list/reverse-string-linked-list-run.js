const reverseStringLinkedList = require('./reverse-string-linked-list');

const result = reverseStringLinkedList('Hello World!');

console.log(result);
