function Node() {}

function DoublyLinkedList() {}

module.exports = DoublyLinkedList;
