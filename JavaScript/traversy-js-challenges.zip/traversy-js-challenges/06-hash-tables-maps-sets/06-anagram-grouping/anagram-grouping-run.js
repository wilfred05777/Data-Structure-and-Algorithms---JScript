const anagramGrouping = require('./anagram-grouping');

const result = anagramGrouping(['cat', 'act', 'dog', 'god', 'tac']);

console.log(result);
