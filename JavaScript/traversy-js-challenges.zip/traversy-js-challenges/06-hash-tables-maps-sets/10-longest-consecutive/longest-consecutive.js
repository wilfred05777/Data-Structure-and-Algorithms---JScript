function longestConsecutiveSequence() {}

module.exports = longestConsecutiveSequence;
