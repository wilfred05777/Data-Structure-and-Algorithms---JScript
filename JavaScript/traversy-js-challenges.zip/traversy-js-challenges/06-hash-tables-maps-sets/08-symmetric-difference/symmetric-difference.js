function symmetricDifference() {}

module.exports = symmetricDifference;
