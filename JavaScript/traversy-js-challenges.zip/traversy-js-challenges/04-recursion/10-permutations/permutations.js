function permutations() {}

module.exports = permutations;
