const countDown = require('./count-down');

countDown(10);
