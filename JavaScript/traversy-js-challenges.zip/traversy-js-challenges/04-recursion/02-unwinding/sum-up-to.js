function sumUpTo() {}

module.exports = sumUpTo;
