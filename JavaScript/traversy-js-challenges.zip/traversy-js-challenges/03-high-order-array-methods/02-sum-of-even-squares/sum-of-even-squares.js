function sumOfEvenSquares() {}

module.exports = sumOfEvenSquares;
