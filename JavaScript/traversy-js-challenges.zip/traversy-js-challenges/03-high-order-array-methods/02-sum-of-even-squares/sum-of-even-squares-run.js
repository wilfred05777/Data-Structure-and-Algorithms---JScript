const sumOfEvenSquares = require('./sum-of-even-squares');

const result = sumOfEvenSquares([1, 2, 3, 4, 5, 6]);

console.log(result);
