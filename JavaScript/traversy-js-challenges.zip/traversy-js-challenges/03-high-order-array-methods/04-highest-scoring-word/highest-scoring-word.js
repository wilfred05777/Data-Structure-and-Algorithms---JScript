function highestScoringWord() {}

module.exports = highestScoringWord;
