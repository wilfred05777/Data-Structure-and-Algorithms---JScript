function validAnagrams() {}

module.exports = validAnagrams;
