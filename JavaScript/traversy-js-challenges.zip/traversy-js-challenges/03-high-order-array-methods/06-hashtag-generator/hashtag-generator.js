function generateHashtag() {}

module.exports = generateHashtag;
