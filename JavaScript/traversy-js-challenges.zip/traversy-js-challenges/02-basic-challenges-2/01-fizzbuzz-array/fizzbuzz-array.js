function fizzBuzzArray() {}

module.exports = fizzBuzzArray;
