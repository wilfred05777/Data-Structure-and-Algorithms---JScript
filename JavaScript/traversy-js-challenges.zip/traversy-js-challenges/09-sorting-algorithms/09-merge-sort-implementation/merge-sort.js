function mergeSort() {}

module.exports = mergeSort;
