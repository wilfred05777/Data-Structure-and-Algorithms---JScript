function findMaxNumber() {}

module.exports = findMaxNumber;
