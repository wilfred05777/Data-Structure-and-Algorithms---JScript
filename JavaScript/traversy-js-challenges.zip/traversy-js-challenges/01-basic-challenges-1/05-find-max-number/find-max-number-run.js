const findMaxNumber = require('./find-max-number');

const result = findMaxNumber([2, 1, 9, 16, 10]);

console.log(result);
