const countOccurrences = require('./count-occurrences');

const result = countOccurrences('hellLo world', 'l');

console.log(result);
