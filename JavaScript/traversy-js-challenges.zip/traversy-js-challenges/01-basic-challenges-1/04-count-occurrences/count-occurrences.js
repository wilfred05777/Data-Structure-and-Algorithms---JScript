function countOccurrences() {}

module.exports = countOccurrences;
