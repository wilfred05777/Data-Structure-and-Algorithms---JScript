function getSum(a, b) {
  // return the sum of a and b
  return a + b;
}

module.exports = getSum;
