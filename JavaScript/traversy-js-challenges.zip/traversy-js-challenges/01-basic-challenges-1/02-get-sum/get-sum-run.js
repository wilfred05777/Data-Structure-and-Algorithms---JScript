const getSum = require('./get-sum');

const result = getSum(1, 10);

console.log(result);
