function titleCase() {}

module.exports = titleCase;
