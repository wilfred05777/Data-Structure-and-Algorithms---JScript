const reverseString = require('./reverse-string');

const result = reverseString('hello world');

console.log(result);
